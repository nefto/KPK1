﻿namespace Events.Contracts
{
    public interface IReader
    {
        string Read();
    }
}
