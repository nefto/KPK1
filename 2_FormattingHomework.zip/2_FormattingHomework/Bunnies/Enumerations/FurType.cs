﻿namespace Bunnies.Enumerations
{
    public enum FurType
    {
        NotFluffy, ALittleFluffy, Fluffy, FluffyToTheLimit
    }
}
