﻿namespace Task2MakeChuek.Enumerations
{
    public enum PersonSex
    {
        CoolGay,
        Playmate
    }
}
